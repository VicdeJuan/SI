		<footer data-ng-controller="footerController">
			<p class="footer-text">
				Olakase | Víctor de Juan Sanz - Guillermo Julián Moreno |
				{{date}} | {{activeUsers}} usuarios activos
			</p>
		</footer>

	</body>
</html>